# RMCDA

This R package has been developed to serve as a universal library in R for the application of multi-criteria decision making methods. 

<br>

[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.14837902.svg)](https://doi.org/10.5281/zenodo.14837902)

<h3>Installation Guide</h3>

To install R package run the following code:

```
devtools::install_github("AnniceNajafi/RMCDA")
```

<h3>Online Application</h3> 
Web-based application to apply methods can be accessed through <a href="https://najafiannice.shinyapps.io/AHP_app/">this link</a>.

<h3>Contact Information</h3>
For any technical questions, please contact <a href=mailto:annicenajafi27@gmail.com>Annice Najafi</a>. I will try to answer your email as soon as I can - within a day. Please also open an issue on the repo. 

<h3>Modification, Additional Methods</h3>
This is an open-source project and users are encouraged to make any changes that they believe would improve the R package by forking and submitting pull requests. 
<br>
<br>
<br>
Open-source software developed in California, 🇺🇸
