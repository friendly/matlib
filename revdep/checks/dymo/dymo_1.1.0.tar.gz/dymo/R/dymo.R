#' dymo
#'
#' Dynamic Mode Decomposition for Multivariate Time Feature Prediction
#'
#' @docType package
#' @name dymo
"_PACKAGE"
