#' time features example: IBM, AAPL, AMZN, GOOGL and MSFT Close Prices
#'
#' A data frame with with daily with daily prices for some Big Tech Companies since March 2017.
#'
#' @format A data frame with 6 columns and 1336 rows.
#'
#' @source finance.yahoo.com
#'
"time_features"
