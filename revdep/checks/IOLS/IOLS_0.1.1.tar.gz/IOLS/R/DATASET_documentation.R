#' @title Sample Data for Analysis
#'
#' @description A simple \code{data_frame} obtained by a Data Generating Process that is for testing and running of examples
#' \describe{
#' \item{y}{outcome variable}
#' \item{x}{two bivariate normal variables x1 and x2}
#' }
"DATASET"
