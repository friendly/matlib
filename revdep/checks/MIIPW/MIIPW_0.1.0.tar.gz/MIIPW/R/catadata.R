#' @title Repeated measurement data with age,group,gender variable
#'
#' @description dataset of observations made at various timepoints,no missing
#' value in age,group,gender
#' @usage data(catadata)
#' @format A \code{tibble} with 8 columns which are :
#' \describe{
#' \item{age}{age of subject}
#' \item{grp}{group}
#' \item{gen}{gender}
#' \item{0}{Observation on timepoint 0}
#' \item{1}{Observation on timepoint 1}
#' \item{2}{Observation on timepoint 2}
#' \item{3}{Observation on timepoint 3}
#' \item{4}{Observation on timepoint 4}}
#'
#'
"catadata"
