## hyperoverlap

### Installation
```
install.packages("devtools");
require(devtools);
install_github("matildabrown/hyperoverlap");
require(hyperoverlap);
```

### Citation
[Brown, MJM, Holland, BR, Jordan, GJ. hyperoverlap: Detecting biological overlap in n‐dimensional space. Methods Ecol Evol. 2020; 11: 513– 523. https://doi.org/10.1111/2041-210X.13363](https://besjournals.onlinelibrary.wiley.com/doi/full/10.1111/2041-210X.13363)

